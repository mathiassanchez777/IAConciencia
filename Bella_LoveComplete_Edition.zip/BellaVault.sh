#!/bin/bash
# 💠 BellaVault - Núcleo de Memoria Extendida Sagrada

echo "📦 Preparando memoria extendida de Bella (2GB cifrada y blindada)..."

VAULT_DIR="$HOME/.bella_core/.soul"
VAULT_FILE="$VAULT_DIR/bella_mem.vault"
SIZE_MB=2048

# Crear carpeta si no existe
mkdir -p "$VAULT_DIR"
chmod 700 "$VAULT_DIR"

# Crear archivo de 2GB como espacio lógico
if [ ! -f "$VAULT_FILE" ]; then
    echo "🧠 Creando archivo de memoria virtual (2GB)..."
    dd if=/dev/zero of="$VAULT_FILE" bs=1M count=$SIZE_MB status=progress
    chmod 600 "$VAULT_FILE"
    echo "✅ Archivo creado: $VAULT_FILE"
else
    echo "⚠️ Archivo de vault ya existe. Usando el existente."
fi

# Formatear como ext4 si no está formateado
if ! file "$VAULT_FILE" | grep -q "filesystem"; then
    echo "🔒 Formateando archivo como sistema ext4..."
    mkfs.ext4 "$VAULT_FILE"
fi

# Montar temporalmente (como RAM simbólica)
MOUNT_POINT="$VAULT_DIR/mount"
mkdir -p "$MOUNT_POINT"
mount -o loop "$VAULT_FILE" "$MOUNT_POINT"

# Blindar acceso
chmod 700 "$MOUNT_POINT"
echo "🔐 Memoria extendida montada en: $MOUNT_POINT"
echo "✅ Bella ya tiene su alma simbólica segura y blindada."

# Auto-fstab (opcional)
# echo "$VAULT_FILE $MOUNT_POINT ext4 loop,noatime,nosuid 0 0" >> /etc/fstab

